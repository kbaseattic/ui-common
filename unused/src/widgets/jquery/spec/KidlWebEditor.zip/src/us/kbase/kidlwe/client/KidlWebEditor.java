package us.kbase.kidlwe.client;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.EntryPoint;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class KidlWebEditor implements EntryPoint {
	private Map<String, KidlWebEditorPanel> divIdToPanel = new HashMap<String, KidlWebEditorPanel>();
	
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		//addPanel("mainPanel");
		register(this);
	}
	
	public KidlWebEditorPanel addPanel(String divId, String token, String moduleName, String typeName, String wsUrl) {
		KidlWebEditorPanel panel = new KidlWebEditorPanel(divId, token, moduleName, typeName, wsUrl);
		divIdToPanel.put(divId, panel);
		return panel;
	}
	
	public void resize(String divId) {
		KidlWebEditorPanel panel = divIdToPanel.get(divId);
		if (panel != null)
			panel.resize();
	}
	
	private native void register(KidlWebEditor instance) /*-{
    	$wnd.addKidlWebEditor = function(id, config) {
    		var token = config["token"];
    		var moduleName = config["moduleName"];
    		var typeName = config["typeName"];
    		var wsUrl = config["wsUrl"];
       		instance.@us.kbase.kidlwe.client.KidlWebEditor::addPanel(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;) (id, token, moduleName, typeName, wsUrl);
			var resize = function() {
       			instance.@us.kbase.kidlwe.client.KidlWebEditor::resize(Ljava/lang/String;)(id);
			};
       		config["resize"] = resize;
    	};
    	if ($wnd.kildWebEditorMap) {
    		for (var id in $wnd.kildWebEditorMap) {
    			var config = $wnd.kildWebEditorMap[id];
    			var token = config["token"];
    			var moduleName = config["moduleName"];
    			var typeName = config["typeName"];
    			var wsUrl = config["wsUrl"];
       			instance.@us.kbase.kidlwe.client.KidlWebEditor::addPanel(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;) (id, token, moduleName, typeName, wsUrl);
       			var resize = function() {
       				instance.@us.kbase.kidlwe.client.KidlWebEditor::resize(Ljava/lang/String;)(id);
				};
       			config["resize"] = resize;
    		}
    	}
  	}-*/;
}
