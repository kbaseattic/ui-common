package us.kbase.kidlwe.client;

public class console {
	public static final native void log(Object message) /*-{
	    console.log(message);
	}-*/;
}
