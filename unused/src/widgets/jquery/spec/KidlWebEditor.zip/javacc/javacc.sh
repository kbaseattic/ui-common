#!/bin/bash
java -cp javacc-6.1.jar javacc $*
