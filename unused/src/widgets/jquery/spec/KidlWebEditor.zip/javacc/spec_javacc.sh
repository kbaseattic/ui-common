#!/bin/bash
./javacc.sh -OUTPUT_DIRECTORY=../src/us/kbase/kidlwe/client/parser ../src/us/kbase/kidlwe/client/parser/SpecParser.jj